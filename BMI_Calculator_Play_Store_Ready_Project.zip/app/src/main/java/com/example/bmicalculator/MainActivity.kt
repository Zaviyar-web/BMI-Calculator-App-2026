package com.example.bmicalculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

private val BgTop = Color(0xFF061A2B)
private val BgBottom = Color(0xFF052D2C)
private val Card = Color(0xFF0D3045)
private val Accent = Color(0xFF35E875)
private val Teal = Color(0xFF18C8B0)

data class Record(val bmi: Double, val weight: String, val height: String, val time: String, val category: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BmiApp() }
    }
}

@Composable
fun BmiApp() {
    var weight by remember { mutableStateOf("") }
    var height by remember { mutableStateOf("") }
    var bmi by remember { mutableStateOf<Double?>(null) }
    var records by remember { mutableStateOf(listOf<Record>()) }
    var screen by remember { mutableStateOf("home") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = BgTop, surface = Card, primary = Accent, onPrimary = Color(0xFF00200D),
        onBackground = Color.White, onSurface = Color.White
    )) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(BgTop, Color(0xFF08263B), BgBottom))
            )
        ) {
            when (screen) {
                "history" -> HistoryScreen(records) { screen = "home" }
                "about" -> AboutScreen { screen = "home" }
                else -> HomeScreen(
                    weight = weight,
                    height = height,
                    bmi = bmi,
                    onWeight = { weight = it },
                    onHeight = { height = it },
                    onCalculate = {
                        val w = weight.toDoubleOrNull()
                        val hCm = height.toDoubleOrNull()
                        if (w != null && hCm != null && w > 0 && hCm > 0) {
                            val h = hCm / 100.0
                            val value = w / (h * h)
                            bmi = value
                            val cat = category(value)
                            val now = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                            records = listOf(Record(value, "$w kg", "$hCm cm", now, cat)) + records.take(9)
                        }
                    },
                    onReset = { weight = ""; height = ""; bmi = null },
                    onHistory = { screen = "history" },
                    onAbout = { screen = "about" }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    weight: String, height: String, bmi: Double?,
    onWeight: (String) -> Unit, onHeight: (String) -> Unit,
    onCalculate: () -> Unit, onReset: () -> Unit,
    onHistory: () -> Unit, onAbout: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("BMI Calculator", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("Know your BMI • Live healthier", color = Color(0xFFB7D2D7))
                }
                Text("♥", color = Accent, fontSize = 30.sp)
            }
        }

        item {
            GlassCard {
                Text("Enter Your Details", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Use your current weight and height.", color = Color(0xFFB7D2D7), fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                NumberField("Weight (kg)", weight, onWeight, "e.g. 70")
                Spacer(Modifier.height(10.dp))
                NumberField("Height (cm)", height, onHeight, "e.g. 175")
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = onCalculate,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF00200D))
                ) { Text("Calculate BMI", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onReset, modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                ) { Text("↻  Reset") }
            }
        }

        if (bmi != null) {
            item { ResultCard(bmi) }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallNav("History", Modifier.weight(1f), onHistory)
                SmallNav("About BMI", Modifier.weight(1f), onAbout)
            }
        }

        item {
            Text("BMI is a general screening tool and not a diagnosis.", color = Color(0xFF9FB8BE), fontSize = 12.sp)
        }
    }
}

@Composable
fun NumberField(label: String, value: String, onValue: (String) -> Unit, hint: String) {
    OutlinedTextField(
        value = value, onValueChange = onValue,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) }, placeholder = { Text(hint) },
        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF3D6174),
            focusedLabelColor = Accent, cursorColor = Accent
        )
    )
}

@Composable
fun ResultCard(bmi: Double) {
    val cat = category(bmi)
    val msg = when (cat) {
        "Underweight" -> "Below the usual healthy range."
        "Normal Weight" -> "Your BMI is in the usual healthy range."
        "Overweight" -> "Above the usual healthy range."
        else -> "At or above the obesity threshold."
    }
    GlassCard {
        Text("Your BMI", color = Color(0xFFB7D2D7))
        Text("%.1f".format(bmi), fontSize = 52.sp, fontWeight = FontWeight.Bold, color = Accent)
        Text("kg/m²", color = Color(0xFFB7D2D7))
        Spacer(Modifier.height(10.dp))
        Surface(shape = RoundedCornerShape(20.dp), color = Accent.copy(alpha = .16f)) {
            Text(cat, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), color = Accent, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Text(msg, color = Color(0xFFD5E6E8))
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("<18.5" to "Under", "18.5–24.9" to "Normal", "25–29.9" to "Over", "≥30" to "Obese").forEach {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(it.first, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(it.second, fontSize = 10.sp, color = Color(0xFF9FB8BE))
                }
            }
        }
    }
}

@Composable
fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Card.copy(alpha = .88f))
    ) { Column(Modifier.padding(20.dp), content = content) }
}

@Composable
fun SmallNav(text: String, modifier: Modifier, action: () -> Unit) {
    OutlinedButton(onClick = action, modifier = modifier, shape = RoundedCornerShape(18.dp)) {
        Text(text, maxLines = 1)
    }
}

@Composable
fun HistoryScreen(records: List<Record>, back: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("‹  History", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        if (records.isEmpty()) {
            Text("No calculations yet.", color = Color(0xFFB7D2D7))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(records) { r ->
                    GlassCard {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(r.time, fontSize = 12.sp, color = Color(0xFF9FB8BE))
                                Text("${r.weight}  •  ${r.height}", fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("%.1f".format(r.bmi), fontSize = 22.sp, color = Accent, fontWeight = FontWeight.Bold)
                                Text(r.category, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = back, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}

@Composable
fun AboutScreen(back: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("‹  About BMI", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        GlassCard {
            Text("What is BMI?", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Body Mass Index (BMI) is a simple calculation using weight and height. It can be used as a general screening measure of weight status.", color = Color(0xFFD5E6E8))
            Spacer(Modifier.height(18.dp))
            Text("BMI = Weight (kg) ÷ Height² (m)", color = Accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Text("Categories", fontWeight = FontWeight.Bold)
            Text("Underweight  < 18.5\nNormal  18.5 – 24.9\nOverweight  25 – 29.9\nObese  ≥ 30", color = Color(0xFFD5E6E8), lineHeight = 25.sp)
        }
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = back, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}

fun category(bmi: Double): String = when {
    bmi < 18.5 -> "Underweight"
    bmi < 25.0 -> "Normal Weight"
    bmi < 30.0 -> "Overweight"
    else -> "Obese"
}
