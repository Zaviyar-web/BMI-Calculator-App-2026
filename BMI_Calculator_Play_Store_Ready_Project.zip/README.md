# BMI Calculator Android App

A clean, modern BMI calculator built with Kotlin + Jetpack Compose.

## Features
- Weight and height input
- BMI calculation
- Underweight / Normal / Overweight / Obese categories
- BMI gauge-style result
- Reset button
- Recent result history stored locally
- About BMI screen
- Dark blue/green health-themed UI with decorative background

## Open
Open the `BMICalculator` folder in Android Studio and let Gradle sync.
Then run the `app` configuration on an emulator or Android phone.

BMI formula: weight (kg) / height(m)^2


## Play Store
The project targets API 36 for current Google Play new-app requirements. See `PLAY_STORE_ASSETS/RELEASE_CHECKLIST.txt` for the remaining account/signing/hosting steps.
